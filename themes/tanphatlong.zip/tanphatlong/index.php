<?php get_header(); ?>

<?php get_template_part( 'content', 'home' ); ?>

<?php get_footer(); ?>